sap.ui.define([
	'sap/ui/core/mvc/Controller',
	'sap/ui/model/json/JSONModel',
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/core/Fragment",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"    
], function (Controller, JSONModel, MessageToast, MessageBox, Fragment, Filter, FilterOperator) {
        "use strict";

        return Controller.extend("odataapp.controller.MainView", {
            
            onInit: function () {
                this._oWizard = this.byId("CreateProductWizard");
                this._oNavContainer = this.byId("wizardNavContainer");
                this._oWizardContentPage = this.byId("wizardContentPage");
                
                // Lade die Übersichtsseite (zum Überprüfen der eingegebenen Daten) - asynchron per Fragment
                Fragment.load({
                    name: "odataapp.view.ReviewPage",
                    controller: this
                }).then(function (oWizardReviewPage) {
                    this._oWizardReviewPage = oWizardReviewPage;
                    // Das Fragment - Die geladene Page dem Navigationscontainer hinzufügen, dadurch kann man nun dorthin navigieren
                    this._oNavContainer.addPage(this._oWizardReviewPage);
                }.bind(this));

                var oModel = this.getOwnerComponent().getModel();
                this.getView().setModel(oModel);                            
                if (oModel.isMetadataLoadingFailed())  {
                    MessageBox.error("Fehler beim Laden der OData Metadaten. Ist der Service erreichbar und verfügbar?");
                }
                oModel.attachMetadataFailed(null, function() {
                    MessageBox.error("Fehler beim Laden der OData Metadaten. Ist der Service erreichbar und verfügbar?");
                });
            },

            onAfterRendering: function() {
                var oModel = this.getOwnerComponent().getModel();
                var oNewContext = oModel.createEntry("/ScarrSet");
                 var sPath = oNewContext.getPath();
                 this.getView().bindElement(sPath); 
            },

            onTableAddRow: function () {
                var oTableRowContext = this.getView().getModel().createEntry("/SpfliSet");
                // Get the template of the items aggregation
                var oTemplate = this.getView().byId("smartTable").getTable().getBindingInfo("items").template;

                // Clone the template
                var oNewItem = oTemplate.clone();

                // Set the binding context of the new item to the created entry
                oNewItem.setBindingContext(oTableRowContext);

                // Add the new item to the table
                this.getView().byId("smartTable").getTable().addItem(oNewItem);
            },    

            onTableRowDelete: function(oEvent) {
                var oItem = oEvent.getParameter("listItem");
                var oContext = oItem.getBindingContext();
                oItem.unbindContext();
                this.getView().getModel().deleteCreatedEntry(oContext);               
                this.getView().byId("smartTable").getTable().removeItem(oItem);
            },
            
            onBeforeRebindSmartTable: function(oEvent) {
                var mBindingParams = oEvent.getParameter("bindingParams");
                // Setze absichtlich einen Filter auf leeren Eintrag -  für initiales Datenladen der Smarttable, 
                // damit keine aktuellen Einträge aus dem Entityset aus dem Backend angezeigt werden, sondern die SmartTable am Anfang leer ist
                 mBindingParams.filters.push(
                    new Filter(
                        "Carrid",
                        FilterOperator.EQ,
                        '|'                    )
                );
            },            

            onAdditionalInfoValidation: function () {
                let bError = false;
                const aTableRows = this.getView().byId("smartTable").getTable().getItems();
                for (var oRow of aTableRows) {
                    var aCells = oRow.getCells();
                    for (var oCell of aCells) {
                        if (oCell.getValueState() === "Error") {
                            bError = true;
                            return;
                        }
                    }
                }
                if (bError) {
                    this._oWizard.invalidateStep(this.byId("ScheduleFlightsStep"));
                } else {
                    this._oWizard.validateStep(this.byId("ScheduleFlightsStep"));
                }
            },

            onSmartTableFieldChange: function(oEvent) {
                var aRows = oEvent.getSource().getTable().getItems();
                for (var oRow of aRows) {
                    var aCells = oRow.getCells();
                    for (var oCell of aCells) {
                        if (oCell.getValueState() === "Error") {
                            this.byId("ScheduleFlightsStep").setValidated(false);
                            return;
                        }
                    }
                }
                this.byId("ScheduleFlightsStep").setValidated(true);
            },

            onAfterNavigate: function (oEvent) {
                var aTableRows = this.getView().byId("smartTable").getTable().getItems();
                const oReviewTable = sap.ui.getCore().byId("smartTableReview").getTable();    
                oReviewTable.removeAllItems();            
                for (var iRowIndex in aTableRows) {
                    var oRow = aTableRows[iRowIndex];
                    var oTemplate = oReviewTable.getBindingInfo("items").template;
                    var oNewRowItem = oTemplate.clone();
                    oNewRowItem.setBindingContext(oRow.getBindingContext());
                    oReviewTable.addItem(oNewRowItem);
                }
            },
    
            onWizardCompletedHandler: function () {
                var bError = false;
                const aTableRows = this.getView().byId("smartTable").getTable().getItems();
                for (var oRow of aTableRows) {
                    var aCells = oRow.getCells();
                    for (var oCell of aCells) {
                        if (oCell.getValueState() === "Error") {
                            bError = true;
                        }
                    }
                }
                if (bError) {
                    sap.m.MessageBox.error("Bitte korrigieren Sie Ihre Eingaben.");
                } else {
                    var oTable = this.getView().byId("smartTableReview");
                    this._oNavContainer.to(this._oWizardReviewPage);
                }
            },
    
            onEditStepOne: function () {
                this._handleNavigationToStep(0);
            },
    
            onEditStepTwo: function () {
                this._handleNavigationToStep(1);
            },
    
            onEditStepThree: function () {
                this._handleNavigationToStep(2);
            },

            backToWizardContent: function () {
                this._oNavContainer.backToPage(this._oWizardContentPage.getId());
            },            
    
            _handleNavigationToStep: function (iStepNumber) {
                var fnAfterNavigate = function () {
                    this._oWizard.goToStep(this._oWizard.getSteps()[iStepNumber]);
                    this._oNavContainer.detachAfterNavigate(fnAfterNavigate);
                }.bind(this);
    
                this._oNavContainer.attachAfterNavigate(fnAfterNavigate);
                this.backToWizardContent();
            },
    
            _handleMessageBoxOpen: function (sMessage, sMessageBoxType, fnFunctionAfterClose) {
                MessageBox[sMessageBoxType](sMessage, {
                    actions: [MessageBox.Action.YES, MessageBox.Action.NO],
                    onClose: fnFunctionAfterClose
                });
            },

            onHandleWizardCancel: function () {
                this._handleMessageBoxOpen("Sind Sie sicher, dass Sie abbrechen wollen?", "warning", this.onCancel.bind(this));
            },
    
            onHandleWizardSubmit: function () {
                this._handleMessageBoxOpen("Sind Sie sicher, dass Sie die Daten abschicken wollen?", "confirm", this.onConfirmSubmit.bind(this));
            },

            onCancel: function(oAction) {
                if (oAction === MessageBox.Action.NO) {
                    return;
                }                
                this._handleNavigationToStep(0);
                this._oWizard.discardProgress(this._oWizard.getSteps()[0]);
            },

            onConfirmSubmit: function(oAction) {
                if (oAction === MessageBox.Action.NO) {
                    return;
                }

                var oModel = this.getView().getModel();
                var oDeepEntityEntry = {};
                var aHeaderToItem = [];
                var oChanges = oModel.getPendingChanges();    
                for (var sKey in oChanges) {
                    if (sKey.includes("SpfliSet")) {
                        aHeaderToItem.push(oChanges[sKey]);          
                    } else if (sKey.includes("ScarrSet")) {
                        oDeepEntityEntry = oChanges[sKey];
                    }
                }
                oDeepEntityEntry.HeaderToItem = aHeaderToItem;
                
                var oModel= this.getView().getModel();
                // Ladeicon einschalten
                this.getView().setBusy(true);
                oModel.create("/ScarrSet", oDeepEntityEntry, {
                    success:  function(oData)  {
                        MessageBox["information"]("Create war Erfolgreich");
                        oModel.resetChanges()
                        // Ladeicon ausschalten
                        this.getView().setBusy(false);
                    }.bind(this),
                    error: function (oError) {
                        MessageBox["information"]("Fehler beim Create mit Deep Entity.");
                        oModel.resetChanges()
                        // Ladeicon ausschalten
                        this.getView().setBusy(false);
                    }.bind(this)
                });	                     

            }        

            
        });
    });
