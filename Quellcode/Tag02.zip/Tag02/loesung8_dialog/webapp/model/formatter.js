sap.ui.define([

], 
function () {
    "use strict";

    return {
        formatName: function(sFirstName, sLastName) {
            return "Vorname: " + sFirstName + "Nachname: " + sLastName;
          }
    };

});