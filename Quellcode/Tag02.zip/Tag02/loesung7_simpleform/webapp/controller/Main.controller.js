sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "loesung1/model/formatter",
],
function (meinController, JSONModel , formatter) {
    "use strict";

    return meinController.extend("loesung1.controller.Main", {
        
        oFormatter : formatter,

        onInit: function () {

            var oModel = new JSONModel({"SupplierCollection": [
		{
			"SupplierName": "Red Point Stores",
			"Street": "Main St",
			"HouseNumber": "1618",
			"ZIPCode": "31415",
			"City": "Maintown",
			"Country": "Germany",
			"Url": "http://www.sap.com",
			"Twitter": "@sap",
			"Tel" : "+49 6227 747474",
			"Sms" : "+49 173 123456",
			"Email" : "john.smith@sap.com"
		}
	]});       
            this.getView().setModel(oModel);

        }
    }

    );
});
