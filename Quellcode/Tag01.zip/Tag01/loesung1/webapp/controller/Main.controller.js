sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel"
],
function (meinController, JSONModel) {
    "use strict";

    return meinController.extend("loesung1.controller.Main", {
        onInit: function () {
         
            var oModel = new JSONModel( {"text1": "Text1", "text2": "Text2"}); 
            this.getView().setModel(oModel, "modelmitKey");
        },

        onButtonPress: function (oEvent) {
            var oModel = this.getView().getModel("modelmitKey");
            oModel.setProperty("/text1", "Text1 aktualisiert");
            oModel.setProperty("/text2", "Text2 aktualisiert");
        }
    });
});
