sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/UIComponent",
    "sap/base/util/deepClone"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller,
        UIComponent,
        deepClone) {
        "use strict";

        return Controller.extend("odataapp.controller.MainView", {
            onInit: function () {

            },

            onAfterOpenDialog: function (oEvent) {
                var that = this;

                this.oNewCreateContext = this.getView().getModel().createEntry("SFlightSet");

                this.getView().byId("addFlightDialog").bindElement(this.oNewCreateContext.getPath());
            },

            onAfterCloseDialog: function (oEvent) {
                if (this.oNewCreateContext) {
                    this.getView().getModel().resetChanges([this.oNewCreateContext.getPath()], true, true);
                }
            },

            onPress: function (oEvent) {
                // The source is the list item that got pressed
                const oItem = oEvent.getSource();
                this._showObject(oItem);
            },

            onAddIconPressed: function () {
                const oInitialEntry = {};

                var oCreatedContext = this.getView().getModel().createEntry("/SFlightSet");
                // Get the template of the items aggregation
                var oTemplate = this.getView().byId("smartTable").getTable().getBindingInfo("items").template;

                // Clone the template
                var oNewItem = oTemplate.clone();

                // Set the binding context of the new item to the created entry
                oNewItem.setBindingContext(oCreatedContext);

                // Add the new item to the table
                this.getView().byId("smartTable").getTable().addItem(oNewItem);
            },

            onAddFlight: function (oEvent) {
                var that = this;
                var oContext = this.getView().byId("addFlightDialog").getBindingContext();
                var oNewObject = oContext.getObject();

                this.getView().getModel().create("/SFlightSet", oNewObject, {
                    success: function (oData) {
                        alert("Create war Erfolgreich");
                        that.onCloseDialog();
                    },
                    error: function (oError) {
                        alert("Fehler beim Create");
                    }
                });
                //this.getView().byId("smartTable").getTable().	
            },

            onCloseDialog: function () {
                this.getView().byId("addFlightDialog").close();
            },

            getRouter: function () {
                return UIComponent.getRouterFor(this);
            },

            /**
             * Shows the selected item on the object page
             * On phones a additional history entry is created
             * @param {sap.m.ObjectListItem} oItem selected Item
             * @private
             */
            _showObject: function (oItem) {
                var dDate = oItem.getBindingContext().getProperty("Fldate");
                var sFldate = dDate.toISOString();
                this.getRouter().navTo("RouteDetail", {
                    carrid: oItem.getBindingContext().getProperty("Carrid"),
                    connid: oItem.getBindingContext().getProperty("Connid"),
                    fldate: sFldate
                });
            }

        });
    });
