sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel"
],
function (meinController, JSONModel) {
    "use strict";

    return meinController.extend("loesung1.controller.Main", {
        onInit: function () {
            var oModel = new JSONModel({
                product: {
                    name: "Laptop"
                }
            });
            this.getView().setModel(oModel);
        }
    });
});
