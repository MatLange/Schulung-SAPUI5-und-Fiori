sap.ui.define([
	"loesung1/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
