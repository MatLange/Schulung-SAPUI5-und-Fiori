sap.ui.define([

], function () {
	"use strict";

	return {

        formatFullName: function (sFirstName, sLastName) {
            return sFirstName + " " + sLastName;
        },
        
        formatIcon: function (sFirstName, sLastName) {
            if (sFirstName === "John") {
            	return "sap-icon://accessibility";
            }
            return "sap-icon://account";
            	
        },        
	

	};
});