/* global QUnit */

sap.ui.require(["loesung1/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
