sap.ui.define([
    "sap/ui/core/mvc/Controller"
],
function (Controller) {
    "use strict";

    return Controller.extend("loesung1.controller.Main", {
        onInit: function () {
            var oModel = new sap.ui.model.json.JSONModel( {"text": "Hallo", defaultBindingMode: "TwoWay"}); 
            //oModel.setDefaultBindingMode("TwoWay");

            this.getView().setModel(oModel, "viewModel");
        }

/*         onPress: function (oEvent) {
            this.getView().getModel("viewModel").setProperty("/text", "Gedrückt");
        } */
    });
});
