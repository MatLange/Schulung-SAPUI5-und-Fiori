sap.ui.define([
    "sap/ui/core/mvc/Controller"
], function (Controller) {
    "use strict";
    return Controller.extend("myApp.controller.Main", {
        onInit: function () {
            // Initialisierungslogik
        },
        onSliderChange: function (oEvent) {
            var iValue = oEvent.getParameter("value");
            this.getView().byId("sliderValue").setText("Wert: " + iValue);
        }
    });
});