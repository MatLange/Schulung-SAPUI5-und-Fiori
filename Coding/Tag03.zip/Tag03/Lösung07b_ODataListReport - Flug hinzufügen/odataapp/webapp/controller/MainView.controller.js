sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/UIComponent"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, UIComponent) {
        "use strict";

        return Controller.extend("odataapp.controller.MainView", {
            onInit: function () {

            },

            onAfterOpenDialog:function(oEvent) {
                var that = this;
                
                this.oNewCreateContext = this.getView().getModel().createEntry("SFlightSet");			
                
                this.getView().byId("addFlightDialog").bindElement(this.oNewCreateContext.getPath());
            },
            
            onAfterCloseDialog:function(oEvent) {
                if (this.oNewCreateContext) {
                    this.getView().getModel().resetChanges([this.oNewCreateContext.getPath()], true, true);	
                }
            },
  
            onPress : function (oEvent) {
                // The source is the list item that got pressed
                const oItem = oEvent.getSource();
                this._showObject(oItem);
            },

            onAddIconPressed :function() {
                var that = this;
    
                if (this.getView().byId("addFlightDialog") === null || this.getView().byId("addFlightDialog") === undefined) {
                    this.loadFragment({
                        type: "XML",
                        name: "odataapp.view.dialogs.Dialog"
                    }).then(function (oDialog)  {
                        that.getView().addDependent(oDialog);
                        oDialog.open();
                    });
                }
                else {
                    this.getView().byId("addFlightDialog").open();
                }		
            },

            onAddFlight: function(oEvent) {
                var that = this;
                var oContext = this.getView().byId("addFlightDialog").getBindingContext();
                var oNewObject = oContext.getObject();
                
                this.getView().getModel().create("/SFlightSet", oNewObject, {
                    success:  function(oData)  {
                        alert("Create war Erfolgreich");
                        that.onCloseDialog();
                    },
                    error: function (oError) {
                        alert("Fehler beim Create");
                    }
                });				
            },            

            onCloseDialog:function() {
                this.getView().byId("addFlightDialog").close();
            },            

            getRouter : function () {
                return UIComponent.getRouterFor(this); 
            },

            /**
             * Shows the selected item on the object page
             * On phones a additional history entry is created
             * @param {sap.m.ObjectListItem} oItem selected Item
             * @private
             */
            _showObject: function (oItem) {
                var dDate = oItem.getBindingContext().getProperty("Fldate");
                var sFldate = dDate.toISOString();
                this.getRouter().navTo("RouteDetail", {
                    carrid: oItem.getBindingContext().getProperty("Carrid"),
                    connid: oItem.getBindingContext().getProperty("Connid"),
                    fldate: sFldate
                });
            }     
    
        });
    });
