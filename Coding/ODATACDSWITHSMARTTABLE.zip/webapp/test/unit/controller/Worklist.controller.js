/*global QUnit*/

sap.ui.define([
	"schulung/ODATACDSWITHSMARTTABLE/controller/Worklist.controller"
], function (Worklist) {
	"use strict";

	QUnit.module("Returns valid min date");

	QUnit.test("Should return a valid min date", function (assert) {
		var oWorklistController = new Worklist();
		var dDate = oWorklistController.formatMinDate();

		// Assert
		assert.ok(dDate, "The date was valid");
	});


});
