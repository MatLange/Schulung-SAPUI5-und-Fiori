sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"../model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (BaseController, JSONModel, formatter, Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("schulung.ODATACDSWITHSMARTTABLE.controller.Worklist", {

		controllerFormatter: formatter,
		

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit : function () {

		},
		
		onAddIconPressed:function() {
			
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Triggered by the table's 'updateFinished' event: after new table
		 * data is available, this handler method updates the table counter.
		 * This should only happen if the update was successful, which is
		 * why this handler is attached to 'updateFinished' and not to the
		 * table's list binding's 'dataReceived' method.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished : function (oEvent) {
			// update the worklist's object counter after the table update
			var sTitle,
				oTable = oEvent.getSource(),
				iTotalItems = oEvent.getParameter("total");
			// only update the counter if the length is final and
			// the table is not empty
			if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
			} else {
				sTitle = this.getResourceBundle().getText("worklistTableTitle");
			}
			this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
		},

		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		onPress : function (oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},

		/**
		 * Event handler for navigating back.
		 * We navigate back in the browser history
		 * @public
		 */
		onNavBack : function() {
			// eslint-disable-next-line sap-no-history-manipulation
			history.go(-1);
		},
		
		onAfterOpenDialog:function(oEvent) {
			var that = this;
			
			this.oNewCreateContext = this.getModel().createEntry("ZDEMO_CDS_SFLIGHT");			
			
			this.byId("addFlightDialog").bindElement(this.oNewCreateContext.getPath());
		},
		
		onAfterCloseDialog:function(oEvent) {
			if (this.oNewCreateContext) {
				this.getModel().resetChanges([this.oNewCreateContext.getPath()], true, true);	
			}
		},
		
		onAddIconPressed :function() {
			var that = this;

			if (this.byId("addFlightDialog") === null || this.byId("addFlightDialog") === undefined) {
				this.loadFragment({
					type: "XML",
					name: "schulung.ODATACDSWITHSMARTTABLE.view.dialogs.Dialog"
				}).then(function (oDialog)  {
					that.getView().addDependent(oDialog);
					oDialog.open();
				});
			}
			else {
				this.byId("addFlightDialog").open();
			}		
		},
		
		onAddFlight: function(oEvent) {
			var that = this;
			var oContext = this.byId("addFlightDialog").getBindingContext();
			var oNewObject = oContext.getObject();
			
			this.getView().getModel().create("/ZDEMO_CDS_SFLIGHT", oNewObject, {
				success:  function(oData)  {
					alert("Create war Erfolgreich");
					that.onCloseDialog();
				},
				error: function (oError) {
					alert("Fehler beim Create");
				}
			});				
		},

		onDeleteFlight: function(oEvent) {
			var oItem = oEvent.getParameter("listItem");
			var sModelPath = oItem.getBindingContext().getPath();
			this.getView().getModel().remove(sModelPath, {
				success: function (oData) {
					alert("Löschen war Erfolgreich");
				},
				error: function (oError) {
					alert("Fehler beim Löschen");
				}
			});				
		},

		onCloseDialog:function() {
			this.byId("addFlightDialog").close();
		},
		
		onSearch : function (oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
			} else {
				var aTableSearchState = [];
				var sQuery = oEvent.getParameter("query");

				if (sQuery && sQuery.length > 0) {
					aTableSearchState = [new Filter("carrid", FilterOperator.Contains, sQuery)];
				}
				this._applySearch(aTableSearchState);
			}

		},
		
		formatMinDate: function() {
			var dToday = new Date();
			var dTomorrow = new Date();
			dTomorrow.setDate(dToday.getDate() + 1);
			return dTomorrow;
		},

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh : function () {
			var oTable = this.byId("table");
			oTable.getBinding("items").refresh();
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showObject: function (oItem) {
			var dDate = oItem.getBindingContext().getProperty("fldate");
			var sFldate = dDate.toISOString();
			this.getRouter().navTo("object", {
				carrid: oItem.getBindingContext().getProperty("carrid"),
				connid: oItem.getBindingContext().getProperty("connid"),
				fldate: sFldate
			});
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @param {sap.ui.model.Filter[]} aTableSearchState An array of filters for the search
		 * @private
		 */
		_applySearch: function(aTableSearchState) {
			var oTable = this.byId("table"),
				oViewModel = this.getModel("worklistView");
			oTable.getBinding("items").filter(aTableSearchState, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (aTableSearchState.length !== 0) {
				oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
			}
		}

	});
});