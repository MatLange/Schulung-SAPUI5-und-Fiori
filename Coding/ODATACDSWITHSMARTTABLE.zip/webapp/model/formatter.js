sap.ui.define([], function () {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit : function (sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},
		
		rewriteUrl: function () {
			//var location = window.location;
			var newHref = "https://com.oeffentliche.fiorizfspmfioripartner/sap/bc/zfspmpartner/app";
			var sPath = "/sap/bc/zfspmpartner/app" + "/Policennummer";
			var policyNumber = "47110815";
			var parts;

			//Check if Bit onPrem or SAP Cloud Plattform
			if (newHref.indexOf("bits") !== -1) {
				newHref = this._splitUrl(newHref);
				// newHref = newHref.replace("zfspmpartner", "zfspmpolicy");
				// newHref = newHref.replace("com.oeffentliche.fiorizfspmfioripartner", "com.oeffentliche.fiorizfspmfioripolicy");
				// parts = newHref.split("&");
				// if (parts[parts.length - 1].indexOf("partner") !== -1) {
				// 	parts[parts.length - 1] = "policynumber=" + policyNumber;
				// } else {
				// 	parts[parts.length - 1] = parts[parts.length - 1] + "&policynumber=" + policyNumber;
				// }

				newHref = "";
				for (var a = 0; a < parts.length; a++) {
					if (a === 0) {
						newHref = newHref + parts[a];
					} else {
						newHref = newHref + "&" + parts[a];
					}
				}

			} else if (location.host.indexOf("dispatcher.hana.ondemand") !== -1) {
				newHref = newHref.replace("zfspmfioripartner", "zfspmfioripolicy");
				parts = newHref.split("?");
				if (parts[parts.length - 1].indexOf("partner") !== -1) {
					parts[parts.length - 1] = "policynumber=" + policyNumber;
				} else {
					parts[parts.length - 1] = parts[parts.length - 1] + "?policynumber=" + policyNumber;
				}

				newHref = "";
				for (var b = 0; b < parts.length; b++) {
					if (b === 0) {
						newHref = newHref + parts[b];
					} else {
						newHref = newHref + "?" + parts[b];
					}
				}
			}
			return newHref;
		},
		

	};

});