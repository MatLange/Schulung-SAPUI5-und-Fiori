sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function (JSONModel, Device) {
	"use strict";

	return {

		createDeviceModel: function () {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},

		createTextModelOneWay: function () {
			var oModel = new JSONModel({
				textOneWayBinding: "Dies ist ein Onewaybinding Text"
			});
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},

		createTextModelTwoWay: function () {
			var oModel = new JSONModel({
				textTwoWayBinding: "Dies ist ein Twowaybinding Text"
			});
			//oModel.setDefaultBindingMode("TwoWay");
			
			return oModel;
		},
		
		createPropertyBindingModel: function () {
			var oModel = new JSONModel({
				user: { firstName: "John", 
						lastName: "Doe" } 				
			});
			return oModel;
		},
		
		createProductsModel: function () {
			var oModel = new JSONModel({
				products:  [{ name: "Schokobrezel", 
						price: 10 },
						{ name: "Nikolaus", 
						price: 1000 },
						{ name: "Sellerie", 
						price: 15.30 },
						{ name: "Tomatenketchpp", 
						price: 65 } 							
						]
			});
			return oModel;
		},

	};
});