sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"schulung/MVCUebung/model/models",
	"schulung/MVCUebung/model/formatter"
], function (Controller, JSONModel, MessageBox, models, localFormatter) {
	"use strict";
	return Controller.extend("schulung.MVCUebung.controller.Main", {
		formatter: localFormatter,
		onInit: function () {
			// var oModel = new sap.ui.model.json.JSONModel({
			//     user: [
			//     	{firstName: "John", lastName: "Doe"},
			//     	{firstName: "Hans", lastName: "Dampf"}
			//     	]
			// });  
			var oModel = models.createPropertyBindingModel();
			this.getView().setModel(oModel);
			
			// var oModel = models.createProductsModel();
			// this.getView().setModel(oModel, "products");			
			
		},
		/**
		 *@memberOf schulung.MVCUebung.controller.Main
		 */
		onToggleButton: function (oEvent) {
			sap.m.MessageBox.information("Toggle Button gedrückt");
		},
		
		onItemPress: function (oEvent) {
			var oSelectedItem = oEvent.getSource();
			const oItemData = oSelectedItem.getBindingContext("products").getObject();
			//sap.m.MessageBox.information("List Item " + oItemData.name + " gedrückt");
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.navTo("Detail", {productId: oItemData.name});
		},
		
		onDeleteItem: function(oEvent) {
			var oSelectedItem = oEvent.getSource();
			const oItemName = oSelectedItem.getBindingContext("products").getObject().name;
			const oModel = oSelectedItem.getBindingContext("products").getModel();
			const aData = oModel.getData().products;
			
			const aUpdatedData = aData.filter(function (oEntry) {
				return oEntry.name !== oItemName;
			});
			
			oModel.setProperty("/products", aUpdatedData );
		}
	});
});